//! Conservative expression lowering. Unsupported forms retain the strict evaluator.
use crate::expr::{Captures, EvalError, Expr, Value};

#[derive(Clone, Copy, Debug)]
pub enum Transform { Identity, Lower, Upper }
impl Transform {
    fn byte(self, b: u8) -> u8 {
        match self { Self::Identity => b, Self::Lower => b.to_ascii_lowercase(), Self::Upper => b.to_ascii_uppercase() }
    }
}
#[derive(Debug)]
pub enum FastExpr {
    Length { id: usize, n: usize, op: String },
    Equal { id: usize, transform: Transform, value: Vec<u8> },
    Emit { id: usize, transform: Transform },
}
impl FastExpr {
    fn id(&self) -> usize { match self { Self::Length{id,..}|Self::Equal{id,..}|Self::Emit{id,..} => *id } }
    pub fn compile(e: &Expr) -> Option<Self> {
        if let Expr::Apply {id, body, arg, ..} = e {
            if let Expr::Cap(cap) = arg.as_ref() {
                fn subst(e: &Expr, id: usize, cap: usize) -> Expr {
                    match e {
                        Expr::Var(v) if *v == id => Expr::Cap(cap),
                        Expr::Op(op, args) => Expr::Op(op.clone(), args.iter().map(|e| subst(e,id,cap)).collect()),
                        _ => e.clone(),
                    }
                }
                let f = Self::compile(&subst(body,*id,*cap))?;
                // The lowered expression reads this same capture first, retaining
                // strict evaluation of the dynamic argument (including limits).
                return (f.id() == *cap).then_some(f);
            }
        }
        fn view(e: &Expr) -> Option<(usize, Transform)> {
            match e {
                Expr::Cap(id) => Some((*id, Transform::Identity)),
                Expr::Op(op, a) if a.len()==1 => match (&a[0], op.as_str()) {
                    (Expr::Cap(id), "lower") => Some((*id, Transform::Lower)),
                    (Expr::Cap(id), "upper") => Some((*id, Transform::Upper)),
                    _ => None,
                },
                _ => None,
            }
        }
        if let Some((id,transform)) = view(e) { return Some(Self::Emit{id,transform}); }
        if let Expr::Op(op,args) = e {
            if let [Expr::Op(len, a), Expr::Val(Value::Nat(n))] = args.as_slice() {
                if len=="len" && matches!(op.as_str(), "le"|"lt"|"eq") {
                    if let [Expr::Cap(id)] = a.as_slice() { return Some(Self::Length{id:*id,n:*n,op:op.clone()}); }
                }
            }
            if op=="eq" {
                if let [lhs,Expr::Val(Value::Str(value))] = args.as_slice() {
                    let (id,transform)=view(lhs)?;
                    return Some(Self::Equal{id,transform,value:value.clone()});
                }
            }
        }
        None
    }
    /// Return a successful consumed-byte count (zero for a guard), or failure.
    pub fn test(&self,input:&[u8],caps:&Captures,pos:usize,limit:usize)->Result<Option<usize>,EvalError> {
        let (a,z)=caps[self.id()].filter(|(a,z)| a<=z && *z<=input.len()).ok_or(EvalError::Unset)?;
        if z-a>limit { return Err(EvalError::Limit); }
        let s=&input[a..z];
        match self {
            Self::Length{n,op,..} => Ok(match op.as_str() {"le"=>s.len()<=*n,"lt"=>s.len()<*n,_=>s.len()==*n}.then_some(0)),
            Self::Equal{transform,value,..} => {
                if value.len()>limit { return Err(EvalError::Limit); }
                Ok((s.len()==value.len() && s.iter().zip(value).all(|(a,b)| transform.byte(*a)==*b)).then_some(0))
            }
            Self::Emit{transform,..} => {
                Ok((input.len()-pos>=s.len() && s.iter().zip(&input[pos..]).all(|(a,b)| transform.byte(*a)==*b)).then_some(s.len()))
            }
        }
    }
}
